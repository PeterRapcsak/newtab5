export const domElements = {
    currency: {
        fromSelect: document.getElementById('from-currency'),
        toSelect: document.getElementById('to-currency'),
        amountInput: document.getElementById('amount'),
        resultInput: document.getElementById('result')
    },
    search: {
        input: document.getElementById('search-q'),
        button: document.getElementById('search-btn'),
        advancedButton: document.getElementById('advanced-btn')
    },
    advancedSearch: document.getElementById('advanced-search'),
    shortcuts: {
        wrapper: document.getElementById('shortcuts-wrapper'),
        container: document.getElementById('shortcuts-wrapper'), // Alias for compatibility
        addForm: document.querySelector('.add-shortcut'),
        newName: document.getElementById('new-shortcut-name'),
        newUrl: document.getElementById('new-shortcut-url'),
        addButton: document.getElementById('add-shortcut-btn')
    },
    buttons: {
        edit: null,
        new: null,
        import: null,
        export: null
    }
};